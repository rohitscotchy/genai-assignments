/**
 * USD price per 1,000,000 tokens, by provider and model.
 * Source: provider pricing pages, checked 2026-09-15.
 *
 * NOTE: InceptionLabs mercury-2.5 is at an 80% launch promo rate
 * (list price is $0.20 input / $0.75 output per 1M tokens) and may change.
 * Testleaf (internal gateway) and Claude (no API integration yet) have no
 * known per-token pricing and are intentionally omitted.
 */
export const PRICING = {
  openai: {
    'gpt-4o':      { input: 2.50,  output: 10.00 },
    'gpt-4o-mini': { input: 0.15,  output: 0.60  }
  },
  groq: {
    'openai/gpt-oss-120b': { input: 0.15,  output: 0.60 },
    'openai/gpt-oss-20b':  { input: 0.075, output: 0.30 }
  },
  inceptionlabs: {
    'mercury-2.5':  { input: 0.04, output: 0.15 },
    'mercury-2':    { input: 0.25, output: 0.75 },
    'mercury-edit': { input: 0.25, output: 0.75 }
  }
};

/**
 * Returns the cost in USD for the given provider/model and token counts,
 * or null when no pricing is known (e.g. testleaf, claude, unlisted models).
 */
export function calculateCost(provider, model, inputTokens, outputTokens) {
  const rate = PRICING[provider]?.[model];
  if (!rate) return null;

  const inputCost = (inputTokens / 1_000_000) * rate.input;
  const outputCost = (outputTokens / 1_000_000) * rate.output;
  return inputCost + outputCost;
}

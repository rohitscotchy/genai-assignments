class InceptionLabsAPI {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.baseUrl = 'https://api.inceptionlabs.ai/v1/chat/completions';
    }

    async sendMessage(prompt, modelName) {
        try {
            console.log('Sending request to InceptionLabs API...');
            const response = await fetch(this.baseUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    model: modelName,
                    messages: [{
                        role: 'user',
                        content: prompt
                    }],
                    max_tokens: 4096,
                    temperature: 0.1
                })
            });

            if (!response.ok) {
                const errorData = await response.text();
                console.error('API Response:', response.status, errorData);
                throw new Error(`API call failed: ${response.status} - ${errorData}`);
            }

            const data = await response.json();
            console.log('InceptionLabs API response:', data);

            return {
                content: data.choices[0].message.content,
                usage: {
                    input_tokens: data.usage.prompt_tokens,
                    output_tokens: data.usage.completion_tokens
                }
            };
        } catch (error) {
            console.error('Error calling InceptionLabs API:', error);
            throw error;
        }
    }
}

// Make the class available globally
window.InceptionLabsAPI = InceptionLabsAPI;
